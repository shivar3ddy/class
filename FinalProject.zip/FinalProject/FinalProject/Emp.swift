
import Foundation

class Emp
{
    
    //Private instance variables of Employee class
    
    public private(set) var name:String
    
    public private (set) var employee_number:Int
    
    public private (set) var hire_date:String
    
    init(n : String , emp_number : Int , hiredate :String)
        
    {
        name = n
        employee_number = emp_number
        hire_date = hiredate
    }
    
}

class ProductionWorker : Emp
{
    var Day_Shift : Int = 1
    
    var Night_Shift : Int = 2
    
    var shift : Int
    
    var pay_rate : Double
    
     init(nn: String, emplo_number : Int, hrdate: String , shift_number : Int , payrate : Double) {
        
        shift = shift_number
        
        pay_rate = payrate
        
        super.init(n: nn, emp_number: emplo_number, hiredate: hrdate)
    }
    
    func get_shift(shift : Int) -> Int {
        return shift
    }
    
    func set_shift(shift : Int) -> Int {
        
        self.shift = shift
        
        return shift
    }
}
